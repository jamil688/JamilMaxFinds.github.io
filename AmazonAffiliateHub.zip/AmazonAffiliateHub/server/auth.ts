import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends User {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express): void {
  // Set up session middleware
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'jamilmaxfinds_secret_key',
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    }
  };

  app.use(session(sessionSettings));

  // Admin login endpoints
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // In a real app, we would validate these against the database
      // For demo, we're using hard-coded credentials
      if (username === "admin" && password === "admin123") {
        // Set session data
        req.session.isAdmin = true;
        req.session.user = {
          id: 999, // Demo admin ID
          username: "admin",
          role: "admin"
        };
        
        return res.json({
          success: true,
          user: {
            username: "admin",
            role: "admin"
          }
        });
      }
      
      // Try to find user in the database
      const user = await storage.getUserByUsername(username);
      if (user && await comparePasswords(password, user.password)) {
        // Set session data
        req.session.isAdmin = true;
        req.session.user = user;
        
        return res.json({
          success: true,
          user: {
            username: user.username,
            role: "admin"
          }
        });
      }
      
      return res.status(401).json({ message: "Invalid username or password" });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "An error occurred during login" });
    }
  });
  
  // Admin logout endpoint
  app.post("/api/admin/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });
  
  // Check admin status
  app.get("/api/admin/check", (req, res) => {
    if (req.session.isAdmin) {
      return res.json({
        isAdmin: true,
        user: req.session.user
      });
    }
    
    res.status(401).json({ isAdmin: false });
  });
}