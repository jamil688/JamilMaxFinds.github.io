import { connect } from "connect-pg-simple";
import session from "express-session";
import { and, eq, like, desc, asc, isNull, or } from "drizzle-orm";
import { db } from "./db";
import { 
  users, products, categories, banners, blogs,
  type User, type InsertUser,
  type Product, type InsertProduct,
  type Category, type InsertCategory,
  type Banner, type InsertBanner,
  type Blog, type InsertBlog
} from "@shared/schema";
import { IStorage } from "./storage";

// Database implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    const PostgresStore = connect(session);
    this.sessionStore = new PostgresStore({
      pool: db.dialect.adapter.client,
      createTableIfMissing: true,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.id, id));
    return result[0];
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const result = await db.select().from(categories).where(eq(categories.slug, slug));
    return result[0];
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const result = await db.insert(categories).values(category).returning();
    return result[0];
  }
  
  async updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category> {
    const result = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return result[0];
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    const result = await db
      .delete(categories)
      .where(eq(categories.id, id))
      .returning({ id: categories.id });
    return result.length > 0;
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return db.select().from(products);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id));
    return result[0];
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.slug, slug));
    return result[0];
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return db.select().from(products).where(eq(products.categoryId, categoryId));
  }
  
  async getProductsByCategorySlug(slug: string): Promise<Product[]> {
    const category = await this.getCategoryBySlug(slug);
    if (!category) {
      return [];
    }
    return this.getProductsByCategory(category.id);
  }

  async getFeaturedProducts(limit?: number): Promise<Product[]> {
    let query = db.select()
      .from(products)
      .where(eq(products.featured, true));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }

  async getTrendingProducts(limit?: number): Promise<Product[]> {
    let query = db.select()
      .from(products)
      .where(eq(products.trending, true));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }

  async getHotDeals(limit?: number): Promise<Product[]> {
    let query = db.select()
      .from(products)
      .where(eq(products.hotDeal, true));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }

  async searchProducts(query: string): Promise<Product[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    return db.select()
      .from(products)
      .where(
        or(
          like(products.title, searchTerm),
          like(products.description, searchTerm)
        )
      );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0];
  }
  
  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product> {
    const result = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return result[0];
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    const result = await db
      .delete(products)
      .where(eq(products.id, id))
      .returning({ id: products.id });
    return result.length > 0;
  }

  // Banner methods
  async getBanners(): Promise<Banner[]> {
    return db.select().from(banners);
  }

  async createBanner(banner: InsertBanner): Promise<Banner> {
    const result = await db.insert(banners).values(banner).returning();
    return result[0];
  }
  
  async updateBanner(id: number, banner: Partial<InsertBanner>): Promise<Banner> {
    const result = await db
      .update(banners)
      .set(banner)
      .where(eq(banners.id, id))
      .returning();
    return result[0];
  }
  
  async deleteBanner(id: number): Promise<boolean> {
    const result = await db
      .delete(banners)
      .where(eq(banners.id, id))
      .returning({ id: banners.id });
    return result.length > 0;
  }

  // Blog methods
  async getBlogs(limit?: number): Promise<Blog[]> {
    let query = db.select().from(blogs).orderBy(desc(blogs.publishDate));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return query;
  }

  async getBlogById(id: number): Promise<Blog | undefined> {
    const result = await db.select().from(blogs).where(eq(blogs.id, id));
    return result[0];
  }

  async getBlogBySlug(slug: string): Promise<Blog | undefined> {
    const result = await db.select().from(blogs).where(eq(blogs.slug, slug));
    return result[0];
  }

  async getBlogsByCategory(categoryId: number): Promise<Blog[]> {
    return db.select()
      .from(blogs)
      .where(eq(blogs.categoryId, categoryId))
      .orderBy(desc(blogs.publishDate));
  }
  
  async getBlogsByCategorySlug(slug: string): Promise<Blog[]> {
    const category = await this.getCategoryBySlug(slug);
    if (!category) {
      return [];
    }
    return this.getBlogsByCategory(category.id);
  }

  async createBlog(blog: InsertBlog): Promise<Blog> {
    const blogWithDate = {
      ...blog,
      publishDate: new Date()
    };
    const result = await db.insert(blogs).values(blogWithDate).returning();
    return result[0];
  }
  
  async updateBlog(id: number, blog: Partial<InsertBlog>): Promise<Blog> {
    const result = await db
      .update(blogs)
      .set(blog)
      .where(eq(blogs.id, id))
      .returning();
    return result[0];
  }
  
  async deleteBlog(id: number): Promise<boolean> {
    const result = await db
      .delete(blogs)
      .where(eq(blogs.id, id))
      .returning({ id: blogs.id });
    return result.length > 0;
  }
}