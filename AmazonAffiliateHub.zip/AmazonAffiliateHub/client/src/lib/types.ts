import { Banner, Category, Product } from "@shared/schema";

export interface FilterOptions {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  rating?: number;
  sort?: 'price-asc' | 'price-desc' | 'rating' | 'newest';
}

export interface CountdownTime {
  days: string;
  hours: string;
  minutes: string;
  seconds: string;
}
