import React, { useState } from 'react';
import { Link } from 'wouter';
import { Product } from '@shared/schema';
import { Heart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const { toast } = useToast();
  
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setIsFavorite(!isFavorite);
    
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite ? `${product.title} has been removed from your favorites.` : `${product.title} has been added to your favorites.`,
      duration: 2000,
    });
  };
  
  const renderStars = (rating: number) => {
    return (
      <div className="flex text-[#FF9900] text-sm">
        {[...Array(5)].map((_, i) => {
          if (i < Math.floor(rating)) {
            return <i key={i} className="fas fa-star"></i>;
          } else if (i === Math.floor(rating) && rating % 1 >= 0.5) {
            return <i key={i} className="fas fa-star-half-alt"></i>;
          } else {
            return <i key={i} className="far fa-star"></i>;
          }
        })}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition duration-300 hover:transform hover:-translate-y-1 hover:shadow-lg">
      <div className="relative">
        {product.discountPercentage && (
          <span className="absolute top-2 left-2 bg-[#D9534F] text-white text-xs font-bold px-2 py-1 rounded z-10">
            -{product.discountPercentage}%
          </span>
        )}
        <Link href={`/product/${product.slug}`}>
          <img 
            src={product.imageUrl} 
            alt={product.title} 
            className="w-full h-60 object-cover hover:scale-105 transition-transform duration-500"
          />
        </Link>
        <button 
          className={`absolute top-2 right-2 w-9 h-9 rounded-full bg-white shadow-md flex items-center justify-center transition-colors z-10 ${
            isFavorite ? 'text-red-500 hover:text-red-600' : 'text-gray-400 hover:text-[#FF9900]'
          }`}
          onClick={handleFavoriteClick}
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="p-4">
        <span className="text-gray-500 text-sm">
          {product.categoryId}
        </span>
        <Link href={`/product/${product.slug}`}>
          <h3 className="font-['Poppins'] font-medium text-[#232F3E] mb-2 h-12 overflow-hidden hover:text-[#FF9900] transition">
            {product.title}
          </h3>
        </Link>
        <div className="flex items-center mb-2">
          {renderStars(product.rating)}
          <span className="text-gray-500 text-sm ml-2">({product.reviewCount})</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            {product.originalPrice && (
              <span className="text-gray-500 line-through">${product.originalPrice}</span>
            )}
            <span className="text-[#232F3E] font-bold ml-2">${product.price}</span>
          </div>
          <a 
            href={product.affiliateUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-10 h-10 rounded-full bg-[#FF9900] text-white flex items-center justify-center hover:bg-amber-600 transition"
          >
            <i className="fas fa-shopping-bag"></i>
          </a>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
