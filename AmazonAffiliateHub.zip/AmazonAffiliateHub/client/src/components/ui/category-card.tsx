import React from 'react';
import { Link } from 'wouter';
import { Category } from '@shared/schema';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link href={`/category/${category.slug}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition group block">
        <div className="p-4 flex flex-col items-center">
          <i className={`fas fa-${category.icon} text-4xl text-[#146EB4] mb-3 group-hover:text-[#FF9900] transition`}></i>
          <span className="font-medium">{category.name}</span>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;
