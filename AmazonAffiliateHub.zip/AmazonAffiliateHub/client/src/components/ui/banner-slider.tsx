import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Banner } from '@shared/schema';

const BannerSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: banners = [] } = useQuery<Banner[]>({
    queryKey: ['/api/banners'],
  });

  useEffect(() => {
    if (banners.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [banners.length]);

  if (banners.length === 0) {
    return null;
  }

  return (
    <div className="relative h-64 sm:h-96 overflow-hidden">
      <div className="relative w-full h-full">
        {banners.map((banner, index) => (
          <div 
            key={banner.id}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#232F3E]/80 to-transparent"></div>
            <img 
              src={banner.imageUrl} 
              alt={banner.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute top-1/2 left-8 transform -translate-y-1/2 text-white z-10 max-w-lg">
              <h2 className="text-2xl sm:text-4xl font-bold font-['Poppins'] mb-2">{banner.title}</h2>
              <p className="text-sm sm:text-base mb-4">{banner.description}</p>
              <Link 
                href={banner.buttonUrl}
                className="bg-[#FF9900] hover:bg-amber-600 text-white px-6 py-2 rounded-md font-medium transition inline-block"
              >
                {banner.buttonText}
              </Link>
            </div>
          </div>
        ))}
      </div>
      
      {/* Banner Navigation */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
        {banners.map((_, index) => (
          <button 
            key={index}
            className={`w-3 h-3 rounded-full bg-white focus:outline-none ${
              index === currentSlide ? 'opacity-100' : 'opacity-50'
            }`}
            onClick={() => setCurrentSlide(index)}
            aria-label={`Go to slide ${index + 1}`}
          ></button>
        ))}
      </div>
    </div>
  );
};

export default BannerSlider;
