import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { Category } from '@shared/schema';

const MainNavigation = () => {
  const [location, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between py-3">
          {/* Logo */}
          <div className="flex items-center mb-3 md:mb-0">
            <Link href="/" className="flex items-center">
              <div className="text-3xl font-bold font-['Poppins']">
                <span className="text-[#146EB4]">Jamil</span><span className="text-[#FF9900]">Max</span><span className="text-[#232F3E]">Finds</span>
              </div>
            </Link>
          </div>

          {/* Search Bar */}
          <div className="w-full md:w-2/5 lg:w-1/2 mb-3 md:mb-0 relative">
            <form onSubmit={handleSearch} className="flex">
              <div className="relative w-full">
                <Input
                  type="text"
                  className="w-full px-4 py-2 rounded-l-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#FF9900] focus:border-transparent"
                  placeholder="Search for products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute right-0 top-0 h-full">
                  <Button 
                    type="submit"
                    className="h-full bg-[#FF9900] text-white px-4 rounded-r-md hover:bg-amber-600 transition"
                  >
                    <Search size={18} />
                  </Button>
                </div>
              </div>
            </form>
          </div>

          {/* Navigation Icons */}
          <div className="flex items-center space-x-4">
            <a href="#" className="text-[#232F3E] hover:text-[#FF9900] relative">
              <i className="fas fa-heart text-xl"></i>
              <span className="absolute -top-2 -right-2 bg-[#FF9900] text-white rounded-full text-xs w-5 h-5 flex items-center justify-center">0</span>
            </a>
            <a href="#" className="text-[#232F3E] hover:text-[#FF9900] relative">
              <i className="fas fa-shopping-cart text-xl"></i>
              <span className="absolute -top-2 -right-2 bg-[#FF9900] text-white rounded-full text-xs w-5 h-5 flex items-center justify-center">0</span>
            </a>
          </div>
        </div>

        {/* Category Navigation */}
        <div className="border-t border-gray-200">
          <ul className="flex flex-wrap items-center py-2 overflow-x-auto whitespace-nowrap">
            <li className="mr-6">
              <Link href="/" className="text-[#232F3E] hover:text-[#FF9900] font-medium">
                Home
              </Link>
            </li>
            {categories?.map((category) => (
              <li key={category.id} className="mr-6 group relative">
                <Link 
                  href={`/category/${category.slug}`}
                  className="text-[#232F3E] hover:text-[#FF9900] font-medium flex items-center"
                >
                  {category.name}
                </Link>
              </li>
            ))}
            <li className="mr-6">
              <Link href="/blog" className="text-[#232F3E] hover:text-[#FF9900] font-medium">
                Blog
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default MainNavigation;
