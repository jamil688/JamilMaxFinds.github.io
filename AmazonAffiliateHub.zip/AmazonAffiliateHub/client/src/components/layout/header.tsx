import React from 'react';

const Header = () => {
  return (
    <header className="bg-[#232F3E] text-white">
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          {/* Top Bar with Contact Info */}
          <div className="hidden md:flex space-x-4 text-sm">
            <span><i className="fas fa-envelope mr-1"></i> support@jamilmaxfinds.com</span>
            <span><i className="fas fa-phone-alt mr-1"></i> (555) 123-4567</span>
          </div>
          {/* Account Links */}
          <div className="flex space-x-4 text-sm">
            <a href="#" className="hover:text-[#FF9900]"><i className="fas fa-user mr-1"></i> My Account</a>
            <a href="#" className="hover:text-[#FF9900]"><i className="fas fa-heart mr-1"></i> Wishlist</a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
