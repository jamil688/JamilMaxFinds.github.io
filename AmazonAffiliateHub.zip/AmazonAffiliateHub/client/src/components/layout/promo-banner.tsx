import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { CountdownTime } from '@/lib/types';

const PromoBanner = () => {
  const [timeLeft, setTimeLeft] = useState<CountdownTime>({
    days: '02',
    hours: '12',
    minutes: '45',
    seconds: '30'
  });

  useEffect(() => {
    // Set end date to 3 days from now
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 3);

    const timer = setInterval(() => {
      const now = new Date();
      const diff = endDate.getTime() - now.getTime();

      if (diff <= 0) {
        clearInterval(timer);
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({
        days: String(days).padStart(2, '0'),
        hours: String(hours).padStart(2, '0'),
        minutes: String(minutes).padStart(2, '0'),
        seconds: String(seconds).padStart(2, '0')
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="bg-[#146EB4] rounded-lg overflow-hidden">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-['Poppins'] font-bold text-white mb-4">Special Offer This Week</h2>
            <p className="text-white/90 mb-6">Get exclusive discounts on our selected products. Limited time offer!</p>
            <div className="flex space-x-4 mb-6">
              <div className="bg-white/20 rounded-lg p-3 text-center">
                <span className="block text-2xl font-bold text-white">{timeLeft.days}</span>
                <span className="text-xs text-white/80">Days</span>
              </div>
              <div className="bg-white/20 rounded-lg p-3 text-center">
                <span className="block text-2xl font-bold text-white">{timeLeft.hours}</span>
                <span className="text-xs text-white/80">Hours</span>
              </div>
              <div className="bg-white/20 rounded-lg p-3 text-center">
                <span className="block text-2xl font-bold text-white">{timeLeft.minutes}</span>
                <span className="text-xs text-white/80">Minutes</span>
              </div>
              <div className="bg-white/20 rounded-lg p-3 text-center">
                <span className="block text-2xl font-bold text-white">{timeLeft.seconds}</span>
                <span className="text-xs text-white/80">Seconds</span>
              </div>
            </div>
            <Link 
              href="/category/electronics"
              className="inline-block bg-[#FF9900] hover:bg-amber-600 text-white font-medium px-6 py-3 rounded-md transition w-max"
            >
              Shop Now
            </Link>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1491637639811-60e2756cc1c7" 
              alt="Special Offer Products" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromoBanner;
