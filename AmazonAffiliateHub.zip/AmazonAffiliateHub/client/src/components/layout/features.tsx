import React from 'react';

const Features = () => {
  return (
    <div className="bg-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col items-center text-center p-4">
            <i className="fas fa-truck text-3xl text-[#146EB4] mb-2"></i>
            <h3 className="font-['Poppins'] font-semibold">Free Shipping</h3>
            <p className="text-gray-600 text-sm">On qualified Amazon orders</p>
          </div>
          <div className="flex flex-col items-center text-center p-4">
            <i className="fas fa-award text-3xl text-[#146EB4] mb-2"></i>
            <h3 className="font-['Poppins'] font-semibold">Quality Products</h3>
            <p className="text-gray-600 text-sm">Curated selection for you</p>
          </div>
          <div className="flex flex-col items-center text-center p-4">
            <i className="fas fa-shield-alt text-3xl text-[#146EB4] mb-2"></i>
            <h3 className="font-['Poppins'] font-semibold">Secure Shopping</h3>
            <p className="text-gray-600 text-sm">Through Amazon's platform</p>
          </div>
          <div className="flex flex-col items-center text-center p-4">
            <i className="fas fa-undo text-3xl text-[#146EB4] mb-2"></i>
            <h3 className="font-['Poppins'] font-semibold">Easy Returns</h3>
            <p className="text-gray-600 text-sm">Hassle-free return policy</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;
