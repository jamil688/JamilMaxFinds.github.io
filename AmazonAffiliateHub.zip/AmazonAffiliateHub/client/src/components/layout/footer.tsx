import React from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Category } from '@shared/schema';

const Footer = () => {
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  return (
    <footer className="bg-[#232F3E] text-white">
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold font-['Poppins'] mb-4">
              <span className="text-[#146EB4]">Jamil</span><span className="text-[#FF9900]">Max</span><span className="text-white">Finds</span>
            </div>
            <p className="text-gray-400 mb-4">Your trusted Amazon affiliate partner for discovering amazing products at great prices.</p>
            <div className="flex space-x-3">
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#FF9900] transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#FF9900] transition">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#FF9900] transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-[#FF9900] transition">
                <i className="fab fa-pinterest"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold font-['Poppins'] mb-4">Categories</h3>
            <ul className="space-y-2">
              {categories?.map((category) => (
                <li key={category.id}>
                  <Link 
                    href={`/category/${category.slug}`}
                    className="text-gray-400 hover:text-[#FF9900] transition"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold font-['Poppins'] mb-4">Information</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-400 hover:text-[#FF9900] transition">About Us</Link></li>
              <li><Link href="/affiliate-disclosure" className="text-gray-400 hover:text-[#FF9900] transition">Affiliate Disclosure</Link></li>
              <li><Link href="/privacy-policy" className="text-gray-400 hover:text-[#FF9900] transition">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-gray-400 hover:text-[#FF9900] transition">Terms & Conditions</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-[#FF9900] transition">Contact Us</Link></li>
              <li><Link href="/blog" className="text-gray-400 hover:text-[#FF9900] transition">Blog</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold font-['Poppins'] mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-[#FF9900]"></i>
                <span className="text-gray-400">123 Street Name, City, Country</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt mr-3 text-[#FF9900]"></i>
                <span className="text-gray-400">(555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-3 text-[#FF9900]"></i>
                <span className="text-gray-400">support@jamilmaxfinds.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">© 2023 JamilMaxFinds. All rights reserved. Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates.</p>
          <div className="flex space-x-4">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Amazon.com-Logo.svg/800px-Amazon.com-Logo.svg.png" alt="Amazon Partner" className="h-6" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
