import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertCategorySchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Extend the category schema with additional validation
const categorySchema = insertCategorySchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  slug: z.string().min(2, "Slug must be at least 2 characters"),
  icon: z.string().min(1, "Icon is required"),
});

type CategoryFormValues = z.infer<typeof categorySchema>;

interface CategoryFormProps {
  categoryId?: number;
  onSuccess?: () => void;
  initialData?: any;
}

export default function CategoryForm({ categoryId, onSuccess, initialData }: CategoryFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form with default values
  const form = useForm<CategoryFormValues>({
    resolver: zodResolver(categorySchema),
    defaultValues: initialData || {
      name: "",
      slug: "",
      icon: "",
    },
  });

  // Update form values when initialData changes
  React.useEffect(() => {
    if (initialData) {
      form.reset(initialData);
    }
  }, [initialData, form]);

  // Create/update category mutation
  const mutation = useMutation({
    mutationFn: async (data: CategoryFormValues) => {
      return categoryId
        ? await apiRequest(`/api/categories/${categoryId}`, "PUT", data)
        : await apiRequest("/api/categories", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      
      toast({
        title: `Category ${categoryId ? "updated" : "created"} successfully`,
        description: `The category has been ${categoryId ? "updated" : "created"} successfully.`,
      });
      
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${categoryId ? "update" : "create"} category: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Generate slug from name
  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/\s+/g, "-");
  };

  // Handle name change to auto-generate slug
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const name = e.target.value;
    form.setValue("name", name);
    
    // Only update slug if it's empty or if it matches a previously generated slug
    const currentSlug = form.getValues("slug");
    const previousName = form.getValues("name");
    if (!currentSlug || currentSlug === generateSlug(previousName)) {
      form.setValue("slug", generateSlug(name));
    }
  };

  const onSubmit = async (values: CategoryFormValues) => {
    setIsSubmitting(true);
    try {
      await mutation.mutateAsync(values);
    } catch (error) {
      console.error("Error saving category:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Category Name */}
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category Name*</FormLabel>
              <FormControl>
                <Input 
                  placeholder="Electronics" 
                  {...field} 
                  onChange={handleNameChange}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Slug */}
        <FormField
          control={form.control}
          name="slug"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Slug*</FormLabel>
              <FormControl>
                <Input 
                  placeholder="electronics" 
                  {...field} 
                />
              </FormControl>
              <FormDescription>
                Used in the URL. Auto-generated from name but can be edited.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Icon */}
        <FormField
          control={form.control}
          name="icon"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Icon*</FormLabel>
              <FormControl>
                <Input 
                  placeholder="laptop" 
                  {...field} 
                />
              </FormControl>
              <FormDescription>
                Enter the icon name (e.g., laptop, smartphone, tv). Used for category display.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess?.()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-[#FF9900] hover:bg-amber-600"
          >
            {isSubmitting ? "Saving..." : categoryId ? "Update Category" : "Create Category"}
          </Button>
        </div>
      </form>
    </Form>
  );
}