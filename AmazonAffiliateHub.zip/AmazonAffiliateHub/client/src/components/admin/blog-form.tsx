import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertBlogSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Extend the blog schema with additional validation
const blogSchema = insertBlogSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  slug: z.string().min(3, "Slug must be at least 3 characters"),
  content: z.string().min(50, "Content must be at least 50 characters"),
  excerpt: z.string().min(10, "Excerpt must be at least 10 characters"),
  featureImageUrl: z.string().min(1, "Feature image URL is required"),
  author: z.string().min(2, "Author must be at least 2 characters"),
  categoryId: z.number().nullable(),
});

type BlogFormValues = z.infer<typeof blogSchema>;

interface BlogFormProps {
  blogId?: number;
  onSuccess?: () => void;
  initialData?: any;
}

export default function BlogForm({ blogId, onSuccess, initialData }: BlogFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(initialData?.featureImageUrl || null);

  // Fetch categories for the select dropdown
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Form with default values
  const form = useForm<BlogFormValues>({
    resolver: zodResolver(blogSchema),
    defaultValues: initialData || {
      title: "",
      slug: "",
      content: "",
      excerpt: "",
      featureImageUrl: "",
      author: "",
      categoryId: null,
    },
  });

  // Update form values when initialData changes
  React.useEffect(() => {
    if (initialData) {
      form.reset(initialData);
      setImagePreview(initialData.featureImageUrl);
    }
  }, [initialData, form]);

  // Handle image URL preview
  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setImagePreview(url.length > 0 ? url : null);
  };

  // Create/update blog mutation
  const mutation = useMutation({
    mutationFn: async (data: BlogFormValues) => {
      return blogId
        ? await apiRequest(`/api/blogs/${blogId}`, "PUT", data)
        : await apiRequest("/api/blogs", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blogs"] });
      
      toast({
        title: `Blog post ${blogId ? "updated" : "created"} successfully`,
        description: `The blog post has been ${blogId ? "updated" : "created"} successfully.`,
      });
      
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${blogId ? "update" : "create"} blog post: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Generate slug from title
  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/\s+/g, "-");
  };

  // Handle title change to auto-generate slug
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const title = e.target.value;
    form.setValue("title", title);
    
    // Only update slug if it's empty or if it matches a previously generated slug
    const currentSlug = form.getValues("slug");
    const previousTitle = form.getValues("title");
    if (!currentSlug || currentSlug === generateSlug(previousTitle)) {
      form.setValue("slug", generateSlug(title));
    }
  };

  // Generate excerpt from content if empty
  const generateExcerptFromContent = () => {
    const content = form.getValues("content");
    const currentExcerpt = form.getValues("excerpt");
    
    if (content && !currentExcerpt) {
      // Strip HTML tags and get first 150 characters
      const plainText = content.replace(/<[^>]*>/g, '');
      const excerpt = plainText.substring(0, 150) + (plainText.length > 150 ? '...' : '');
      form.setValue("excerpt", excerpt);
    }
  };

  const onSubmit = async (values: BlogFormValues) => {
    setIsSubmitting(true);
    try {
      await mutation.mutateAsync(values);
    } catch (error) {
      console.error("Error saving blog post:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Blog Title*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="10 Best Electronics Deals This Month" 
                      {...field} 
                      onChange={handleTitleChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Slug */}
            <FormField
              control={form.control}
              name="slug"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Slug*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="10-best-electronics-deals-this-month" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Used in the URL. Auto-generated from title but can be edited.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Category */}
            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(value ? parseInt(value) : null)}
                    defaultValue={field.value?.toString() || ""}
                    value={field.value?.toString() || ""}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category (optional)" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="">None</SelectItem>
                      {categories.map((category) => (
                        <SelectItem 
                          key={category.id} 
                          value={category.id.toString()}
                        >
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Author */}
            <FormField
              control={form.control}
              name="author"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Author*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="John Doe" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Feature Image URL */}
            <FormField
              control={form.control}
              name="featureImageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Feature Image URL*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://images.unsplash.com/photo-example.jpg" 
                      {...field} 
                      onChange={(e) => {
                        field.onChange(e);
                        handleImageUrlChange(e);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Image Preview */}
            {imagePreview && (
              <Card className="overflow-hidden">
                <CardContent className="p-2">
                  <div className="aspect-[16/9] relative">
                    <img 
                      src={imagePreview} 
                      alt="Feature image preview" 
                      className="object-cover w-full h-full"
                      onError={() => setImagePreview(null)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            {/* Excerpt */}
            <FormField
              control={form.control}
              name="excerpt"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Excerpt*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="A short summary of the blog post" 
                      className="h-24"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    A brief summary shown in blog listings. Will be auto-generated from content if left empty.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Content */}
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Content*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="The full blog post content. HTML is supported." 
                      className="h-96 font-mono"
                      {...field} 
                      onBlur={generateExcerptFromContent}
                    />
                  </FormControl>
                  <FormDescription>
                    HTML content for the blog post. You can use paragraphs, headings, lists, etc.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess?.()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-[#FF9900] hover:bg-amber-600"
          >
            {isSubmitting ? "Saving..." : blogId ? "Update Blog Post" : "Create Blog Post"}
          </Button>
        </div>
      </form>
    </Form>
  );
}