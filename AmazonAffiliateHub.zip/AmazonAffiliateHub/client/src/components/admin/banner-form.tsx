import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertBannerSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

// Extend the banner schema with additional validation
const bannerSchema = insertBannerSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(5, "Description must be at least 5 characters"),
  imageUrl: z.string().min(1, "Image URL is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonUrl: z.string().min(1, "Button URL is required"),
  order: z.number().int().min(1, "Order must be at least 1"),
});

type BannerFormValues = z.infer<typeof bannerSchema>;

interface BannerFormProps {
  bannerId?: number;
  onSuccess?: () => void;
  initialData?: any;
}

export default function BannerForm({ bannerId, onSuccess, initialData }: BannerFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(initialData?.imageUrl || null);

  // Form with default values
  const form = useForm<BannerFormValues>({
    resolver: zodResolver(bannerSchema),
    defaultValues: initialData || {
      title: "",
      description: "",
      imageUrl: "",
      buttonText: "Shop Now",
      buttonUrl: "/",
      order: 1,
    },
  });

  // Update form values when initialData changes
  React.useEffect(() => {
    if (initialData) {
      form.reset(initialData);
      setImagePreview(initialData.imageUrl);
    }
  }, [initialData, form]);

  // Handle image URL preview
  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setImagePreview(url.length > 0 ? url : null);
  };

  // Create/update banner mutation
  const mutation = useMutation({
    mutationFn: async (data: BannerFormValues) => {
      return bannerId
        ? await apiRequest(`/api/banners/${bannerId}`, "PUT", data)
        : await apiRequest("/api/banners", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      
      toast({
        title: `Banner ${bannerId ? "updated" : "created"} successfully`,
        description: `The banner has been ${bannerId ? "updated" : "created"} successfully.`,
      });
      
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${bannerId ? "update" : "create"} banner: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (values: BannerFormValues) => {
    setIsSubmitting(true);
    try {
      await mutation.mutateAsync(values);
    } catch (error) {
      console.error("Error saving banner:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Banner Title*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Summer Tech Deals" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Discover amazing discounts on the latest gadgets and electronics" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Button Text */}
            <FormField
              control={form.control}
              name="buttonText"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Button Text*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Shop Now" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Button URL */}
            <FormField
              control={form.control}
              name="buttonUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Button URL*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="/category/electronics" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    The URL the button will link to. For categories use: /category/[slug]
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Order */}
            <FormField
              control={form.control}
              name="order"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Display Order*</FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      min="1"
                      {...field} 
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                      value={field.value}
                    />
                  </FormControl>
                  <FormDescription>
                    The order in which this banner appears (1 appears first)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-6">
            {/* Image URL */}
            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Banner Image URL*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://images.unsplash.com/photo-example.jpg" 
                      {...field} 
                      onChange={(e) => {
                        field.onChange(e);
                        handleImageUrlChange(e);
                      }}
                    />
                  </FormControl>
                  <FormDescription>
                    For best results, use high-resolution landscape images (1200x600px or similar)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Image Preview */}
            {imagePreview && (
              <Card className="overflow-hidden">
                <CardContent className="p-2">
                  <div className="aspect-[2/1] relative bg-gray-100">
                    <img 
                      src={imagePreview} 
                      alt="Banner preview" 
                      className="object-cover w-full h-full"
                      onError={() => setImagePreview(null)}
                    />
                    <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/60 to-transparent p-6 text-white">
                      <h3 className="text-xl font-bold">{form.watch("title")}</h3>
                      <p className="text-sm opacity-90">{form.watch("description")}</p>
                      <div className="mt-2">
                        <span className="inline-block px-4 py-1 bg-[#FF9900] text-white rounded-sm text-sm">
                          {form.watch("buttonText")}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess?.()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-[#FF9900] hover:bg-amber-600"
          >
            {isSubmitting ? "Saving..." : bannerId ? "Update Banner" : "Create Banner"}
          </Button>
        </div>
      </form>
    </Form>
  );
}