import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertProductSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

// Extend the product schema with additional validation
const productSchema = insertProductSchema.extend({
  imageUrl: z.string().min(1, "Image URL is required"),
  price: z.string().min(1, "Price is required"),
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  slug: z.string().min(3, "Slug must be at least 3 characters"),
  affiliateUrl: z.string().min(1, "Amazon affiliate URL is required"),
  categoryId: z.number().min(1, "Category is required"),
  // Optional fields with defaults
  originalPrice: z.string().nullable().optional(),
  discountPercentage: z.number().nullable().optional(),
  featured: z.boolean().default(false),
  trending: z.boolean().default(false),
  hotDeal: z.boolean().default(false),
  rating: z.number().min(0).max(5).default(5),
  reviewCount: z.number().min(0).default(0),
});

type ProductFormValues = z.infer<typeof productSchema>;

interface ProductFormProps {
  productId?: number;
  onSuccess?: () => void;
}

export default function ProductForm({ productId, onSuccess }: ProductFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Fetch categories for the select dropdown
  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Fetch product data if editing an existing product
  const { data: product, isLoading } = useQuery({
    queryKey: ["/api/products", productId],
    queryFn: productId 
      ? async () => {
          const response = await apiRequest(`/api/products/${productId}`, "GET");
          return response;
        }
      : () => null,
    enabled: !!productId,
  });

  // Form with default values
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      title: "",
      slug: "",
      description: "",
      price: "",
      originalPrice: null,
      discountPercentage: null,
      imageUrl: "",
      rating: 5,
      reviewCount: 0,
      categoryId: 0,
      affiliateUrl: "",
      featured: false,
      trending: false,
      hotDeal: false,
    },
  });

  // Update form values when product data is loaded
  React.useEffect(() => {
    if (product) {
      form.reset(product);
      setImagePreview(product.imageUrl);
    }
  }, [product, form]);

  // Calculate discount percentage when price and originalPrice change
  React.useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (
        (name === "price" || name === "originalPrice") &&
        value.price &&
        value.originalPrice
      ) {
        const price = parseFloat(value.price);
        const originalPrice = parseFloat(value.originalPrice as string);
        
        if (price && originalPrice && originalPrice > price) {
          const discountPercentage = Math.round(
            ((originalPrice - price) / originalPrice) * 100
          );
          form.setValue("discountPercentage", discountPercentage);
        }
      }
    });
    
    return () => subscription.unsubscribe();
  }, [form]);

  // Handle image URL preview
  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setImagePreview(url.length > 0 ? url : null);
  };

  // Create/update product mutation
  const mutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      return productId
        ? await apiRequest(`/api/products/${productId}`, "PUT", data)
        : await apiRequest("/api/products", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/featured-products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trending-products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/hot-deals"] });
      
      toast({
        title: `Product ${productId ? "updated" : "created"} successfully`,
        description: `The product has been ${productId ? "updated" : "created"} successfully.`,
      });
      
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${productId ? "update" : "create"} product: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Generate slug from title
  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/\s+/g, "-");
  };

  // Handle title change to auto-generate slug
  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const title = e.target.value;
    form.setValue("title", title);
    
    // Only update slug if it's empty or if it matches a previously generated slug
    const currentSlug = form.getValues("slug");
    const previousTitle = form.getValues("title");
    if (!currentSlug || currentSlug === generateSlug(previousTitle)) {
      form.setValue("slug", generateSlug(title));
    }
  };

  const onSubmit = async (values: ProductFormValues) => {
    setIsSubmitting(true);
    try {
      await mutation.mutateAsync(values);
    } catch (error) {
      console.error("Error saving product:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading && productId) {
    return <div className="text-center p-8">Loading product data...</div>;
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Title*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Amazon Echo Dot (4th Gen)" 
                      {...field} 
                      onChange={handleTitleChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Slug */}
            <FormField
              control={form.control}
              name="slug"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Slug*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="amazon-echo-dot-4th-gen" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Used in the URL. Auto-generated from title but can be edited.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description*</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Smart speaker with improved sound and Alexa..." 
                      className="h-32"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Category */}
            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category*</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value?.toString() || ""}
                    value={field.value?.toString() || ""}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem 
                          key={category.id} 
                          value={category.id.toString()}
                        >
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Price */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price*</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="49.99" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="originalPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Original Price</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="79.99" 
                        {...field} 
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value || null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Discount Percentage - Calculated automatically */}
            <FormField
              control={form.control}
              name="discountPercentage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Discount Percentage</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Auto-calculated" 
                      {...field} 
                      value={field.value?.toString() || ""}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || null)}
                      disabled={true}
                    />
                  </FormControl>
                  <FormDescription>
                    Automatically calculated from Price and Original Price
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-6">
            {/* Image URL */}
            <FormField
              control={form.control}
              name="imageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Image URL*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://m.media-amazon.com/images/I/example.jpg" 
                      {...field} 
                      onChange={(e) => {
                        field.onChange(e);
                        handleImageUrlChange(e);
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Image Preview */}
            {imagePreview && (
              <Card className="overflow-hidden">
                <CardContent className="p-2">
                  <div className="aspect-video relative">
                    <img 
                      src={imagePreview} 
                      alt="Product preview" 
                      className="object-contain w-full h-full"
                      onError={() => setImagePreview(null)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Affiliate URL */}
            <FormField
              control={form.control}
              name="affiliateUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amazon Affiliate URL*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://www.amazon.com/dp/B07XJ8C8F5?tag=yourtag-20" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    The affiliate link used when "Buy on Amazon" is clicked
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Rating and Review Count */}
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="rating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Rating (0-5)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        max="5"
                        step="0.1"
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="reviewCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Review Count</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Featured, Trending, Hot Deal switches */}
            <div className="space-y-3">
              <FormField
                control={form.control}
                name="featured"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Featured Product</FormLabel>
                      <FormDescription>
                        Show in the featured products section
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="trending"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Trending Product</FormLabel>
                      <FormDescription>
                        Show in the trending products section
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="hotDeal"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-3">
                    <div className="space-y-0.5">
                      <FormLabel>Hot Deal</FormLabel>
                      <FormDescription>
                        Show in the hot deals section
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSuccess?.()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-[#FF9900] hover:bg-amber-600"
          >
            {isSubmitting ? "Saving..." : productId ? "Update Product" : "Create Product"}
          </Button>
        </div>
      </form>
    </Form>
  );
}