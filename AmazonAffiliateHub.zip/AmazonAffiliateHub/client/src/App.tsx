import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Product from "@/pages/product";
import Category from "@/pages/category";
import Search from "@/pages/search";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import AffiliateDisclosure from "@/pages/affiliate-disclosure";
import PrivacyPolicy from "@/pages/privacy-policy";
import Terms from "@/pages/terms";
import Blog from "@/pages/blog";
import BlogPost from "@/pages/blog-post";
import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard";
import Header from "@/components/layout/header";
import MainNavigation from "@/components/layout/main-navigation";
import Footer from "@/components/layout/footer";
import BackToTop from "@/components/layout/back-to-top";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/product/:slug" component={Product} />
      <Route path="/category/:slug" component={Category} />
      <Route path="/search" component={Search} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/affiliate-disclosure" component={AffiliateDisclosure} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms" component={Terms} />
      <Route path="/blog" component={Blog} />
      <Route path="/blog/:slug" component={BlogPost} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Layout component for regular pages
function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5]">
      <Header />
      <MainNavigation />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      <BackToTop />
    </div>
  );
}

// Function to check if current path is an admin route
function isAdminRoute(path: string): boolean {
  return path.startsWith('/admin');
}

function App() {
  const [location] = useLocation();
  
  return (
    <QueryClientProvider client={queryClient}>
      {isAdminRoute(location) ? (
        <main>
          <Router />
        </main>
      ) : (
        <AppLayout>
          <Router />
        </AppLayout>
      )}
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
