import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  LayoutDashboard, 
  Package, 
  Tag, 
  Image, 
  FileText, 
  User,
  LogOut,
  Plus,
  Edit,
  Trash,
  ChevronRight,
  Search,
  RefreshCw,
  AlertCircle
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

// Admin component imports
import ProductForm from "@/components/admin/product-form";
import CategoryForm from "@/components/admin/category-form";
import BannerForm from "@/components/admin/banner-form";
import BlogForm from "@/components/admin/blog-form";

const MAX_DESCRIPTION_LENGTH = 100;

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("dashboard");
  const { toast } = useToast();

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentItem, setCurrentItem] = useState<any>(null);

  // Filter states
  const [productFilter, setProductFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [bannerFilter, setBannerFilter] = useState("");
  const [blogFilter, setBlogFilter] = useState("");

  // Authenticate admin on load
  useEffect(() => {
    // Check if admin is logged in
    const isAdmin = localStorage.getItem("isAdmin");
    if (!isAdmin) {
      navigate("/admin/login");
    }
  }, [navigate]);

  // Fetch data
  const { 
    data: products = [], 
    isLoading: isLoadingProducts,
    refetch: refetchProducts 
  } = useQuery({
    queryKey: ["/api/products"],
  });

  const { 
    data: categories = [], 
    isLoading: isLoadingCategories,
    refetch: refetchCategories  
  } = useQuery({
    queryKey: ["/api/categories"],
  });

  const { 
    data: banners = [], 
    isLoading: isLoadingBanners,
    refetch: refetchBanners 
  } = useQuery({
    queryKey: ["/api/banners"],
  });

  const { 
    data: blogs = [], 
    isLoading: isLoadingBlogs,
    refetch: refetchBlogs 
  } = useQuery({
    queryKey: ["/api/blogs"],
  });

  // Delete mutations
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/products/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Product deleted",
        description: "The product has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete product: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/categories/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category deleted",
        description: "The category has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete category: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const deleteBannerMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/banners/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
      toast({
        title: "Banner deleted",
        description: "The banner has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete banner: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const deleteBlogMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/blogs/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blogs"] });
      toast({
        title: "Blog post deleted",
        description: "The blog post has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete blog post: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle dialog opening and closing
  const handleAddItem = () => {
    setCurrentItem(null);
    setIsAddDialogOpen(true);
  };

  const handleEditItem = (item: any) => {
    setCurrentItem(item);
    setIsEditDialogOpen(true);
  };

  const handleDeleteItem = (item: any) => {
    setCurrentItem(item);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!currentItem) return;

    try {
      if (activeTab === "products") {
        await deleteProductMutation.mutateAsync(currentItem.id);
      } else if (activeTab === "categories") {
        await deleteCategoryMutation.mutateAsync(currentItem.id);
      } else if (activeTab === "banners") {
        await deleteBannerMutation.mutateAsync(currentItem.id);
      } else if (activeTab === "blogs") {
        await deleteBlogMutation.mutateAsync(currentItem.id);
      }
    } catch (error) {
      console.error("Error deleting item:", error);
    } finally {
      setIsDeleteDialogOpen(false);
      setCurrentItem(null);
    }
  };

  const handleDialogClose = () => {
    setIsAddDialogOpen(false);
    setIsEditDialogOpen(false);
    setCurrentItem(null);
  };

  const handleLogout = () => {
    // Clear admin session
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("adminUser");
    navigate("/admin/login");
  };

  // Filter functions
  const getFilteredProducts = () => {
    if (!productFilter) return products;
    const lowerFilter = productFilter.toLowerCase();
    return products.filter(
      (product) => 
        product.title.toLowerCase().includes(lowerFilter) ||
        product.description.toLowerCase().includes(lowerFilter)
    );
  };

  const getFilteredCategories = () => {
    if (!categoryFilter) return categories;
    const lowerFilter = categoryFilter.toLowerCase();
    return categories.filter(
      (category) => 
        category.name.toLowerCase().includes(lowerFilter) ||
        category.slug.toLowerCase().includes(lowerFilter)
    );
  };

  const getFilteredBanners = () => {
    if (!bannerFilter) return banners;
    const lowerFilter = bannerFilter.toLowerCase();
    return banners.filter(
      (banner) => 
        banner.title.toLowerCase().includes(lowerFilter) ||
        banner.description.toLowerCase().includes(lowerFilter)
    );
  };

  const getFilteredBlogs = () => {
    if (!blogFilter) return blogs;
    const lowerFilter = blogFilter.toLowerCase();
    return blogs.filter(
      (blog) => 
        blog.title.toLowerCase().includes(lowerFilter) ||
        blog.excerpt.toLowerCase().includes(lowerFilter) ||
        blog.content.toLowerCase().includes(lowerFilter)
    );
  };

  // Helper function to truncate text
  const truncateText = (text: string, maxLength: number = MAX_DESCRIPTION_LENGTH) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  // Handle data refresh
  const refreshCurrentData = () => {
    switch (activeTab) {
      case "products":
        refetchProducts();
        break;
      case "categories":
        refetchCategories();
        break;
      case "banners":
        refetchBanners();
        break;
      case "blogs":
        refetchBlogs();
        break;
      default:
        refetchProducts();
        refetchCategories();
        refetchBanners();
        refetchBlogs();
    }

    toast({
      title: "Data refreshed",
      description: "The data has been refreshed successfully.",
    });
  };

  // Get the dialog title based on the active tab
  const getDialogTitle = () => {
    if (isEditDialogOpen) {
      switch (activeTab) {
        case "products": return "Edit Product";
        case "categories": return "Edit Category";
        case "banners": return "Edit Banner";
        case "blogs": return "Edit Blog Post";
        default: return "Edit Item";
      }
    } else {
      switch (activeTab) {
        case "products": return "Add Product";
        case "categories": return "Add Category";
        case "banners": return "Add Banner";
        case "blogs": return "Add Blog Post";
        default: return "Add Item";
      }
    }
  };

  // Load state for delete button
  const isDeleteLoading = 
    deleteProductMutation.isPending || 
    deleteCategoryMutation.isPending || 
    deleteBannerMutation.isPending || 
    deleteBlogMutation.isPending;

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-[#232F3E] text-white">
        <div className="p-4 text-xl font-bold">
          <span className="text-[#146EB4]">Jamil</span><span className="text-[#FF9900]">Max</span><span className="text-white">Finds</span>
        </div>
        <div className="p-2">
          <p className="text-gray-400 px-2 mb-2 text-xs uppercase">Navigation</p>
          <button 
            className={`w-full flex items-center p-2 rounded-md mb-1 ${activeTab === "dashboard" ? "bg-[#FF9900] text-white" : "text-gray-300 hover:bg-gray-700"}`} 
            onClick={() => setActiveTab("dashboard")}
          >
            <LayoutDashboard className="mr-2 h-5 w-5" />
            Dashboard
          </button>
          <button 
            className={`w-full flex items-center p-2 rounded-md mb-1 ${activeTab === "products" ? "bg-[#FF9900] text-white" : "text-gray-300 hover:bg-gray-700"}`} 
            onClick={() => setActiveTab("products")}
          >
            <Package className="mr-2 h-5 w-5" />
            Products
          </button>
          <button 
            className={`w-full flex items-center p-2 rounded-md mb-1 ${activeTab === "categories" ? "bg-[#FF9900] text-white" : "text-gray-300 hover:bg-gray-700"}`} 
            onClick={() => setActiveTab("categories")}
          >
            <Tag className="mr-2 h-5 w-5" />
            Categories
          </button>
          <button 
            className={`w-full flex items-center p-2 rounded-md mb-1 ${activeTab === "banners" ? "bg-[#FF9900] text-white" : "text-gray-300 hover:bg-gray-700"}`} 
            onClick={() => setActiveTab("banners")}
          >
            <Image className="mr-2 h-5 w-5" />
            Banners
          </button>
          <button 
            className={`w-full flex items-center p-2 rounded-md mb-1 ${activeTab === "blogs" ? "bg-[#FF9900] text-white" : "text-gray-300 hover:bg-gray-700"}`} 
            onClick={() => setActiveTab("blogs")}
          >
            <FileText className="mr-2 h-5 w-5" />
            Blogs
          </button>
        </div>
        <div className="absolute bottom-4 left-4 right-4">
          <button 
            className="w-full flex items-center p-2 rounded-md text-gray-300 hover:bg-gray-700" 
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-5 w-5" />
            Logout
          </button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Header */}
        <div className="bg-white shadow-sm">
          <div className="p-4 flex justify-between items-center">
            <h1 className="text-xl font-semibold">Admin Dashboard</h1>
            <div className="flex items-center gap-4">
              <Button
                variant="outline" 
                size="sm"
                onClick={refreshCurrentData}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button
                className="bg-[#FF9900] hover:bg-amber-600"
                onClick={() => navigate("/")}
              >
                View Site
              </Button>
            </div>
          </div>
        </div>
        
        {/* Content Area */}
        <div className="p-6">
          {/* Dashboard Overview */}
          {activeTab === "dashboard" && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Dashboard Overview</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Products
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{products?.length || 0}</div>
                    <Button 
                      variant="ghost" 
                      className="mt-2 p-0 h-auto text-blue-600"
                      onClick={() => setActiveTab("products")}
                    >
                      View all <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Categories
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{categories?.length || 0}</div>
                    <Button 
                      variant="ghost" 
                      className="mt-2 p-0 h-auto text-blue-600"
                      onClick={() => setActiveTab("categories")}
                    >
                      View all <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Banners
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{banners?.length || 0}</div>
                    <Button 
                      variant="ghost" 
                      className="mt-2 p-0 h-auto text-blue-600"
                      onClick={() => setActiveTab("banners")}
                    >
                      View all <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Blog Posts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{blogs?.length || 0}</div>
                    <Button 
                      variant="ghost" 
                      className="mt-2 p-0 h-auto text-blue-600"
                      onClick={() => setActiveTab("blogs")}
                    >
                      View all <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Recent Content Section */}
              <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Products</CardTitle>
                    <CardDescription>Latest products added to the website</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {products?.slice(0, 5).map((product) => (
                        <div key={product.id} className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded overflow-hidden bg-gray-100">
                            <img 
                              src={product.imageUrl} 
                              alt={product.title} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium truncate">{product.title}</div>
                            <div className="text-sm text-muted-foreground">${product.price}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Blog Posts</CardTitle>
                    <CardDescription>Latest blog posts published on the website</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {blogs?.slice(0, 5).map((blog) => (
                        <div key={blog.id} className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded overflow-hidden bg-gray-100">
                            <img 
                              src={blog.featureImageUrl} 
                              alt={blog.title} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium truncate">{blog.title}</div>
                            <div className="text-sm text-muted-foreground">By {blog.author}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          
          {/* Products Tab */}
          {activeTab === "products" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Products</h2>
                <Button 
                  className="bg-[#FF9900] hover:bg-amber-600"
                  onClick={handleAddItem}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Product
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search products..."
                    className="pl-10"
                    value={productFilter}
                    onChange={(e) => setProductFilter(e.target.value)}
                  />
                </div>
              </div>
              
              {isLoadingProducts ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Loading products...</p>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {getFilteredProducts().map((product) => {
                          const category = categories.find(c => c.id === product.categoryId);
                          return (
                            <tr key={product.id}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.id}</td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="w-10 h-10 rounded overflow-hidden bg-gray-100">
                                  <img 
                                    src={product.imageUrl} 
                                    alt={product.title} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div>
                                  <div>{product.title}</div>
                                  <div className="text-xs text-gray-400 truncate max-w-[300px]">
                                    {truncateText(product.description)}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <div>
                                  <div className="font-medium">${product.price}</div>
                                  {product.originalPrice && (
                                    <div className="text-xs line-through text-gray-400">
                                      ${product.originalPrice}
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {category?.name || "Unknown"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm">
                                <div className="flex flex-wrap gap-1">
                                  {product.featured && (
                                    <Badge variant="outline" className="border-blue-500 text-blue-500">
                                      Featured
                                    </Badge>
                                  )}
                                  {product.trending && (
                                    <Badge variant="outline" className="border-purple-500 text-purple-500">
                                      Trending
                                    </Badge>
                                  )}
                                  {product.hotDeal && (
                                    <Badge variant="outline" className="border-red-500 text-red-500">
                                      Hot Deal
                                    </Badge>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <div className="flex space-x-2">
                                  <Button
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8"
                                    onClick={() => handleEditItem(product)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8 text-red-500 hover:text-red-700"
                                    onClick={() => handleDeleteItem(product)}
                                  >
                                    <Trash className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Categories Tab */}
          {activeTab === "categories" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Categories</h2>
                <Button 
                  className="bg-[#FF9900] hover:bg-amber-600"
                  onClick={handleAddItem}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Category
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search categories..."
                    className="pl-10"
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                  />
                </div>
              </div>
              
              {isLoadingCategories ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Loading categories...</p>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Slug</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Icon</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Products</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {getFilteredCategories().map((category) => (
                          <tr key={category.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{category.id}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{category.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{category.slug}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{category.icon}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {products?.filter(p => p.categoryId === category.id).length || 0}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <div className="flex space-x-2">
                                <Button
                                  variant="outline" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => handleEditItem(category)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline" 
                                  size="icon" 
                                  className="h-8 w-8 text-red-500 hover:text-red-700"
                                  onClick={() => handleDeleteItem(category)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Banners Tab */}
          {activeTab === "banners" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Banners</h2>
                <Button 
                  className="bg-[#FF9900] hover:bg-amber-600"
                  onClick={handleAddItem}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Banner
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search banners..."
                    className="pl-10"
                    value={bannerFilter}
                    onChange={(e) => setBannerFilter(e.target.value)}
                  />
                </div>
              </div>
              
              {isLoadingBanners ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Loading banners...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {getFilteredBanners().map((banner) => (
                    <Card key={banner.id} className="overflow-hidden">
                      <div className="aspect-[2/1] relative">
                        <img 
                          src={banner.imageUrl} 
                          alt={banner.title} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/60 to-transparent p-4 text-white">
                          <h3 className="text-lg font-bold">{banner.title}</h3>
                          <p className="text-sm opacity-90">{truncateText(banner.description, 60)}</p>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="text-sm text-gray-500">Order: {banner.order}</div>
                            <div className="text-sm text-gray-500 mt-1">Button: {banner.buttonText}</div>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline" 
                              size="icon" 
                              className="h-8 w-8"
                              onClick={() => handleEditItem(banner)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline" 
                              size="icon" 
                              className="h-8 w-8 text-red-500 hover:text-red-700"
                              onClick={() => handleDeleteItem(banner)}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
          
          {/* Blogs Tab */}
          {activeTab === "blogs" && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Blog Posts</h2>
                <Button 
                  className="bg-[#FF9900] hover:bg-amber-600"
                  onClick={handleAddItem}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Blog Post
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search blog posts..."
                    className="pl-10"
                    value={blogFilter}
                    onChange={(e) => setBlogFilter(e.target.value)}
                  />
                </div>
              </div>
              
              {isLoadingBlogs ? (
                <div className="text-center py-8">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                  <p className="mt-2 text-gray-500">Loading blog posts...</p>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Author</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {getFilteredBlogs().map((blog) => {
                          const category = blog.categoryId 
                            ? categories.find(c => c.id === blog.categoryId) 
                            : null;
                          
                          return (
                            <tr key={blog.id}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{blog.id}</td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="w-10 h-10 rounded overflow-hidden bg-gray-100">
                                  <img 
                                    src={blog.featureImageUrl} 
                                    alt={blog.title} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div>
                                  <div>{blog.title}</div>
                                  <div className="text-xs text-gray-400 truncate max-w-[300px]">
                                    {truncateText(blog.excerpt, 60)}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{blog.author}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {new Date(blog.publishDate).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {category?.name || "None"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <div className="flex space-x-2">
                                  <Button
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8"
                                    onClick={() => handleEditItem(blog)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline" 
                                    size="icon" 
                                    className="h-8 w-8 text-red-500 hover:text-red-700"
                                    onClick={() => handleDeleteItem(blog)}
                                  >
                                    <Trash className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isAddDialogOpen || isEditDialogOpen} onOpenChange={handleDialogClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{getDialogTitle()}</DialogTitle>
            <DialogDescription>
              {isEditDialogOpen 
                ? `Edit the details for this ${activeTab.slice(0, -1)}.` 
                : `Fill in the details to create a new ${activeTab.slice(0, -1)}.`}
            </DialogDescription>
          </DialogHeader>
          
          {activeTab === "products" && (
            <ProductForm 
              productId={currentItem?.id} 
              onSuccess={handleDialogClose} 
            />
          )}
          
          {activeTab === "categories" && (
            <CategoryForm 
              categoryId={currentItem?.id} 
              initialData={currentItem}
              onSuccess={handleDialogClose} 
            />
          )}
          
          {activeTab === "banners" && (
            <BannerForm 
              bannerId={currentItem?.id} 
              initialData={currentItem}
              onSuccess={handleDialogClose} 
            />
          )}
          
          {activeTab === "blogs" && (
            <BlogForm 
              blogId={currentItem?.id} 
              initialData={currentItem}
              onSuccess={handleDialogClose} 
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              <div className="flex items-center gap-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                Confirm Deletion
              </div>
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this {activeTab.slice(0, -1)}?
              <div className="mt-2">
                {currentItem?.title && <div className="font-medium">{currentItem.title}</div>}
                {currentItem?.name && <div className="font-medium">{currentItem.name}</div>}
              </div>
              <div className="mt-4 text-sm text-red-500">
                This action cannot be undone.
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleteLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                confirmDelete();
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
              disabled={isDeleteLoading}
            >
              {isDeleteLoading ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}