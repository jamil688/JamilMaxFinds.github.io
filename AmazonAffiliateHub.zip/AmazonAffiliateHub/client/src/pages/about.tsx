import React from 'react';

const AboutPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-['Poppins'] font-bold text-[#232F3E] mb-6">About Us</h1>
        
        <div className="prose max-w-none">
          <p className="mb-4">
            Welcome to JamilMaxFinds – your trusted destination for finding the best products on Amazon!
          </p>
          
          <p className="mb-4">
            Founded in 2023, JamilMaxFinds was created with a simple mission: to help online shoppers discover high-quality products at great prices. We understand that navigating through millions of products on Amazon can be overwhelming, which is why our team of product enthusiasts carefully curates and reviews products across various categories.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Our Mission</h2>
          <p className="mb-4">
            Our mission is to simplify your shopping experience by providing honest recommendations, detailed product information, and the best deals available on Amazon. We believe that informed shoppers make better purchasing decisions.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">What We Do</h2>
          <p className="mb-4">
            At JamilMaxFinds, we:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Research and test products to find the best options in each category</li>
            <li>Monitor price changes to alert you of great deals</li>
            <li>Keep up with the latest product releases and trends</li>
            <li>Provide honest reviews and recommendations</li>
            <li>Help you navigate to the best products on Amazon</li>
          </ul>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Our Team</h2>
          <p className="mb-4">
            Our team consists of passionate product researchers, tech enthusiasts, and everyday consumers who understand what shoppers are looking for. We come from diverse backgrounds but share a common goal – to help you find products that enhance your life.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Affiliate Disclosure</h2>
          <p className="mb-4">
            JamilMaxFinds is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com. This means that we may earn a commission when you click on our links and make a purchase on Amazon, at no additional cost to you.
          </p>
          <p className="mb-4">
            For more information about our affiliate relationships, please visit our <a href="/affiliate-disclosure" className="text-[#146EB4] hover:text-[#FF9900]">Affiliate Disclosure</a> page.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Contact Us</h2>
          <p className="mb-4">
            We value your feedback and are always looking to improve our service. If you have any questions, suggestions, or concerns, please don't hesitate to <a href="/contact" className="text-[#146EB4] hover:text-[#FF9900]">contact us</a>.
          </p>
          
          <p className="mt-8">
            Thank you for choosing JamilMaxFinds as your shopping companion. We're excited to help you discover amazing products!
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;