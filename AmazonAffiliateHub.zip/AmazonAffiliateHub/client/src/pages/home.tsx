import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Product, Category } from '@shared/schema';
import BannerSlider from '@/components/ui/banner-slider';
import Features from '@/components/layout/features';
import ProductCard from '@/components/ui/product-card';
import CategoryCard from '@/components/ui/category-card';
import PromoBanner from '@/components/layout/promo-banner';
import Newsletter from '@/components/layout/newsletter';
import { Skeleton } from '@/components/ui/skeleton';

const Home = () => {
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: hotDeals, isLoading: hotDealsLoading } = useQuery<Product[]>({
    queryKey: ['/api/hot-deals'],
  });

  const { data: featuredProducts, isLoading: featuredLoading } = useQuery<Product[]>({
    queryKey: ['/api/featured-products'],
  });

  return (
    <>
      <BannerSlider />
      
      <Features />
      
      {/* Featured Categories */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] mb-2">Shop By Category</h2>
          <div className="h-1 w-20 bg-[#FF9900]"></div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categoriesLoading ? (
            Array(6).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-4 flex flex-col items-center">
                  <Skeleton className="h-16 w-16 rounded-full mb-3" />
                  <Skeleton className="h-6 w-24" />
                </div>
              </div>
            ))
          ) : (
            categories?.map(category => (
              <CategoryCard key={category.id} category={category} />
            ))
          )}
        </div>
      </div>
      
      {/* Hot Deals Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] mb-2">Today's Hot Deals</h2>
            <div className="h-1 w-20 bg-[#FF9900]"></div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {hotDealsLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-4 w-20 mb-2" />
                  <Skeleton className="h-12 w-full mb-2" />
                  <Skeleton className="h-4 w-32 mb-2" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-10 w-10 rounded-full" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            hotDeals?.map(product => (
              <ProductCard key={product.id} product={product} />
            ))
          )}
        </div>
        
        <div className="text-center mt-8">
          <Link href="/category/all">
            <a className="inline-block px-6 py-3 bg-[#146EB4] text-white rounded-md hover:bg-blue-700 transition font-medium">
              View All Deals
            </a>
          </Link>
        </div>
      </div>
      
      {/* Featured Products */}
      <div className="bg-gray-50 py-10">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] mb-2">Featured Products</h2>
            <div className="h-1 w-20 bg-[#FF9900]"></div>
          </div>
          
          {/* Category Filter Buttons */}
          <div className="flex flex-wrap gap-2 mb-8">
            <button className="px-4 py-2 rounded-md bg-[#146EB4] text-white border border-gray-300 hover:bg-[#146EB4] hover:text-white transition">All</button>
            {categories?.map(category => (
              <button 
                key={category.id}
                className="px-4 py-2 rounded-md bg-white border border-gray-300 text-[#232F3E] hover:bg-[#146EB4] hover:text-white transition"
              >
                {category.name}
              </button>
            ))}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {featuredLoading ? (
              Array(5).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <Skeleton className="w-full h-48" />
                  <div className="p-4">
                    <Skeleton className="h-4 w-20 mb-2" />
                    <Skeleton className="h-12 w-full mb-2" />
                    <Skeleton className="h-4 w-32 mb-2" />
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-6 w-20" />
                      <Skeleton className="h-10 w-10 rounded-full" />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              featuredProducts?.map(product => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>
          
          <div className="text-center mt-8">
            <Link href="/category/all">
              <a className="inline-block px-6 py-3 bg-[#146EB4] text-white rounded-md hover:bg-blue-700 transition font-medium">
                View All Products
              </a>
            </Link>
          </div>
        </div>
      </div>
      
      <PromoBanner />
      
      <Newsletter />
    </>
  );
};

export default Home;
