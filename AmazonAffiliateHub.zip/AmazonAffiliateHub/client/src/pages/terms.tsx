import React from 'react';

const TermsPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-['Poppins'] font-bold text-[#232F3E] mb-6">Terms & Conditions</h1>
        
        <div className="prose max-w-none">
          <p className="mb-4">
            Last updated: April 9, 2023
          </p>
          
          <p className="mb-4">
            Please read these Terms and Conditions ("Terms") carefully before using the JamilMaxFinds website. By accessing or using our website, you agree to be bound by these Terms.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Use of the Website</h2>
          <p className="mb-4">
            JamilMaxFinds provides a platform for discovering and learning about products available on Amazon.com. By using our website, you agree to:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Use the website in a manner consistent with all applicable laws and regulations</li>
            <li>Not attempt to interfere with the proper functioning of the website</li>
            <li>Not attempt to access areas of the website not intended for public access</li>
            <li>Not use automated tools or scripts to collect information from the website</li>
            <li>Not impersonate another person or entity</li>
          </ul>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Intellectual Property Rights</h2>
          <p className="mb-4">
            All content on JamilMaxFinds, including text, images, logos, buttons, icons, and software, is the property of JamilMaxFinds or its content suppliers and is protected by international copyright laws. The compilation of all content on this site is the exclusive property of JamilMaxFinds.
          </p>
          <p className="mb-4">
            You may not reproduce, distribute, display, or transmit any of the content on this website without prior written permission from JamilMaxFinds, except for personal, non-commercial use.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Amazon Affiliate Relationship</h2>
          <p className="mb-4">
            JamilMaxFinds is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com. As an Amazon Associate, we earn from qualifying purchases.
          </p>
          <p className="mb-4">
            When you click on links to Amazon.com from our website and make a purchase, we will receive a small commission. This does not affect the price you pay for products on Amazon.
          </p>
          <p className="mb-4">
            For more information about our affiliate relationships, please see our <a href="/affiliate-disclosure" className="text-[#146EB4] hover:text-[#FF9900]">Affiliate Disclosure</a>.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Disclaimer of Warranties</h2>
          <p className="mb-4">
            JamilMaxFinds makes no warranties or representations about the accuracy or completeness of the content on this website. The website and all information, content, materials, and products included on or otherwise made available to you through this site are provided on an "as is" and "as available" basis.
          </p>
          <p className="mb-4">
            To the fullest extent permissible by applicable law, JamilMaxFinds disclaims all warranties, express or implied, including, but not limited to, implied warranties of merchantability and fitness for a particular purpose.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Limitation of Liability</h2>
          <p className="mb-4">
            JamilMaxFinds will not be liable for any damages of any kind arising from the use of this website, including, but not limited to, direct, indirect, incidental, punitive, and consequential damages.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Product Information and Pricing</h2>
          <p className="mb-4">
            While we strive to provide accurate product information and pricing, errors may occasionally occur. JamilMaxFinds reserves the right to correct any errors in product descriptions or pricing. We do not guarantee that the information provided on our website is error-free, complete, or current.
          </p>
          <p className="mb-4">
            Prices and availability of products on Amazon.com are subject to change without notice. We recommend verifying all information before making a purchase.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Links to Third-Party Websites</h2>
          <p className="mb-4">
            JamilMaxFinds may include links to third-party websites. These links are provided for your convenience and do not signify our endorsement of these websites or their content. We have no responsibility for the content of linked third-party sites and are not responsible for any damages or losses incurred when you access these websites.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Changes to Terms and Conditions</h2>
          <p className="mb-4">
            JamilMaxFinds reserves the right to update or modify these Terms at any time without prior notice. Your continued use of the website following any changes indicates your acceptance of the new Terms.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Governing Law</h2>
          <p className="mb-4">
            These Terms shall be governed by and construed in accordance with the laws of the United States, without giving effect to any principles of conflicts of law.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Contact Information</h2>
          <p className="mb-4">
            If you have any questions about these Terms, please <a href="/contact" className="text-[#146EB4] hover:text-[#FF9900]">contact us</a>.
          </p>
          
          <p className="mt-8 italic">
            By using JamilMaxFinds, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsPage;