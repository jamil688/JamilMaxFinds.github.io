import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Product } from '@shared/schema';
import ProductCard from '@/components/ui/product-card';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search as SearchIcon } from 'lucide-react';

const Search = () => {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1]);
  const initialQuery = searchParams.get('q') || '';
  
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [searchTerm, setSearchTerm] = useState(initialQuery);

  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const query = params.get('q') || '';
    setSearchQuery(query);
    setSearchTerm(query);
  }, [location]);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/search', { q: searchTerm }],
    enabled: searchTerm.length > 0,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchTerm(searchQuery);
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-['Poppins'] font-semibold text-[#232F3E] mb-4">
            Search Results
          </h1>
          
          <form onSubmit={handleSearch} className="flex max-w-xl mb-6">
            <Input
              type="text"
              className="flex-grow rounded-r-none border-r-0"
              placeholder="Search for products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit"
              className="rounded-l-none bg-[#FF9900] hover:bg-amber-600"
            >
              <SearchIcon className="mr-2 h-4 w-4" />
              Search
            </Button>
          </form>
          
          {searchTerm && (
            <p className="text-gray-600 mb-6">
              Showing results for "{searchTerm}"
            </p>
          )}
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array(8).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-4 w-20 mb-2" />
                  <Skeleton className="h-12 w-full mb-2" />
                  <Skeleton className="h-4 w-32 mb-2" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-10 w-10 rounded-full" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : products?.length ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : searchTerm ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">No products found</h3>
            <p className="text-gray-600 mb-4">
              We couldn't find any products matching "{searchTerm}"
            </p>
            <p className="text-gray-600">
              Try using different keywords or browse our categories
            </p>
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-2">Enter a search term</h3>
            <p className="text-gray-600">
              Type what you're looking for in the search box above
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;
