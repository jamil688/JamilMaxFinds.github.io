import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { CalendarIcon, Clock, Tag } from "lucide-react";
import { format } from "date-fns";
import { type Blog } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const BlogPage = () => {
  // Fetch blog posts
  const { data: blogs, isLoading: blogsLoading } = useQuery<Blog[]>({
    queryKey: ["/api/blogs"],
  });

  return (
    <div className="container py-8">
      <div className="mb-12 text-center">
        <h1 className="text-3xl md:text-4xl font-semibold mb-4 text-[#232F3E]">
          JamilMaxFinds Blog
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Expert advice, buying guides, and top product recommendations to help you make smarter shopping decisions.
        </p>
      </div>

      {blogsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {Array(6).fill(0).map((_, index) => (
            <Card key={index} className="flex flex-col h-full">
              <Skeleton className="h-48 w-full rounded-t-lg" />
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full mt-2" />
              </CardHeader>
              <CardContent className="flex-grow">
                <Skeleton className="h-20 w-full" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs?.map((blog) => (
            <Card key={blog.id} className="flex flex-col h-full hover:shadow-lg transition-shadow duration-300">
              <div className="h-48 overflow-hidden">
                <img 
                  src={blog.featureImageUrl} 
                  alt={blog.title} 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardHeader>
                <div className="flex items-center text-sm text-gray-500 mb-2 space-x-4">
                  <div className="flex items-center">
                    <CalendarIcon size={14} className="mr-1" />
                    <span>
                      {format(new Date(blog.publishDate), 'MMM d, yyyy')}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Tag size={14} className="mr-1" />
                    <span>Shopping</span>
                  </div>
                </div>
                <CardTitle className="text-[#232F3E] line-clamp-2">
                  {blog.title}
                </CardTitle>
                <CardDescription className="line-clamp-2 mt-2">
                  {blog.excerpt}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="text-gray-600 line-clamp-3 text-sm">
                  {/* Strip HTML tags for excerpt display */}
                  {blog.excerpt}
                </div>
              </CardContent>
              <CardFooter className="pt-0">
                <Link href={`/blog/${blog.slug}`}>
                  <Button className="w-full bg-[#FF9900] hover:bg-amber-600">
                    Read More
                  </Button>
                </Link>
              </CardFooter>
              <div className="px-6 pb-4 flex items-center text-sm text-gray-500">
                <img 
                  src={`https://ui-avatars.com/api/?name=${blog.author}&background=random`} 
                  alt={blog.author}
                  className="w-8 h-8 rounded-full mr-2" 
                />
                <span>By {blog.author}</span>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default BlogPage;