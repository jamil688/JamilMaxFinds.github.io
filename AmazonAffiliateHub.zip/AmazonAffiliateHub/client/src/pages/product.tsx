import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRoute } from 'wouter';
import { Product, Category } from '@shared/schema';
import ProductCard from '@/components/ui/product-card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Heart, ChevronLeft, ChevronRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ProductPage = () => {
  const [, params] = useRoute('/product/:slug');
  const slug = params?.slug;
  const { toast } = useToast();
  
  // Pagination state for related products
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 4;

  const { data: product, isLoading: productLoading } = useQuery<Product>({
    queryKey: [`/api/products/${slug}`],
    enabled: !!slug,
  });

  const { data: category } = useQuery<Category>({
    queryKey: ['/api/categories', product?.categoryId],
    enabled: !!product?.categoryId,
  });

  const { data: relatedProducts, isLoading: relatedLoading } = useQuery<Product[]>({
    queryKey: [`/api/products/category/${category?.slug}`],
    enabled: !!category?.slug,
  });

  const renderStars = (rating: number = 0) => {
    return (
      <div className="flex text-[#FF9900] text-lg">
        {[...Array(5)].map((_, i) => {
          if (i < Math.floor(rating)) {
            return <i key={i} className="fas fa-star"></i>;
          } else if (i === Math.floor(rating) && rating % 1 >= 0.5) {
            return <i key={i} className="fas fa-star-half-alt"></i>;
          } else {
            return <i key={i} className="far fa-star"></i>;
          }
        })}
      </div>
    );
  };

  if (productLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <Skeleton className="w-full h-[400px] rounded-lg" />
            </div>
            <div className="md:w-1/2">
              <Skeleton className="h-8 w-3/4 mb-2" />
              <Skeleton className="h-6 w-1/4 mb-4" />
              <Skeleton className="h-6 w-full mb-3" />
              <Skeleton className="h-6 w-5/6 mb-6" />
              <Skeleton className="h-8 w-1/3 mb-6" />
              <Skeleton className="h-12 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] mb-4">
            Product Not Found
          </h2>
          <p className="text-gray-600 mb-4">
            The product you are looking for does not exist or has been removed.
          </p>
          <a 
            href="/"
            className="inline-block px-6 py-3 bg-[#FF9900] text-white rounded-md hover:bg-amber-600 transition font-medium"
          >
            Back to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm">
          <a href="/" className="text-gray-500 hover:text-[#FF9900]">Home</a>
          <span className="mx-2 text-gray-400">/</span>
          <a href={`/category/${category?.slug || ''}`} className="text-gray-500 hover:text-[#FF9900]">{category?.name || 'Category'}</a>
          <span className="mx-2 text-gray-400">/</span>
          <span className="text-gray-700">{product.title}</span>
        </div>
        
        {/* Product Details */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <div className="rounded-lg overflow-hidden">
                <img 
                  src={product.imageUrl} 
                  alt={product.title} 
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
            <div className="md:w-1/2">
              <h1 className="text-2xl md:text-3xl font-['Poppins'] font-semibold text-[#232F3E] mb-2">
                {product.title}
              </h1>
              
              <div className="flex items-center mb-4">
                {renderStars(product.rating)}
                <span className="text-gray-500 ml-2">({product.reviewCount} reviews)</span>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center">
                  {product.originalPrice && (
                    <span className="text-gray-500 line-through text-lg mr-3">${product.originalPrice}</span>
                  )}
                  <span className="text-2xl font-bold text-[#232F3E]">${product.price}</span>
                  {product.discountPercentage && (
                    <span className="ml-3 bg-[#D9534F] text-white text-sm px-2 py-1 rounded">
                      {product.discountPercentage}% OFF
                    </span>
                  )}
                </div>
                <p className="text-green-600 mt-1">In Stock</p>
              </div>
              
              <div className="flex items-center space-x-4 mb-6">
                <a 
                  href={product.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-grow py-3 bg-[#FF9900] text-white rounded-md font-medium text-center hover:bg-amber-600 transition"
                >
                  Buy on Amazon
                </a>
                <Button 
                  variant="outline" 
                  className="p-3"
                  onClick={() => {
                    toast({
                      title: "Added to Wishlist",
                      description: `${product.title} has been added to your wishlist.`,
                      duration: 2000,
                    });
                  }}
                >
                  <Heart className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Special Amazon Offer Card */}
              <div className="bg-gray-100 rounded-lg p-4 border border-gray-200 hover:border-[#FF9900] transition-colors cursor-pointer mb-6">
                <div className="flex items-center mb-2">
                  <img 
                    src="https://m.media-amazon.com/images/G/01/AdProductsWebsite/images/AUX/ILB_BrightColors_Approved._TTW_.jpg" 
                    alt="Amazon Prime" 
                    className="h-6 mr-2" 
                  />
                  <span className="font-semibold">Special Amazon Offer</span>
                </div>
                <p className="text-gray-600 mb-2">Get exclusive deals and free shipping with Amazon Prime. Try it free for 30 days!</p>
                <a 
                  href="https://www.amazon.com/prime" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-[#146EB4] hover:text-[#FF9900] transition inline-block"
                >
                  Learn more about Amazon Prime →
                </a>
              </div>
              
              {/* Product Description */}
              <div className="bg-white rounded-lg border border-gray-200 mb-6 overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                  <h3 className="font-semibold text-[#232F3E]">Product Description</h3>
                </div>
                <div className="p-4">
                  <p className="text-gray-700">{product.description}</p>
                </div>
              </div>
              
              {/* Product Ads - Small Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-100 rounded-lg p-4 border border-gray-200 hover:border-[#FF9900] transition-colors cursor-pointer">
                  <div className="flex items-center mb-2">
                    <i className="fas fa-percentage text-[#FF9900] mr-2"></i>
                    <span className="font-semibold text-sm">Amazon Coupons</span>
                  </div>
                  <p className="text-sm text-gray-600">Save with deals and coupons on millions of products. Updated daily!</p>
                  <a 
                    href="https://www.amazon.com/Coupons/b?node=2231352011" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-xs text-[#146EB4] hover:text-[#FF9900] transition mt-2 inline-block"
                  >
                    Browse coupons →
                  </a>
                </div>
                
                <div className="bg-gray-100 rounded-lg p-4 border border-gray-200 hover:border-[#FF9900] transition-colors cursor-pointer">
                  <div className="flex items-center mb-2">
                    <i className="fas fa-gift text-[#FF9900] mr-2"></i>
                    <span className="font-semibold text-sm">Amazon Gift Cards</span>
                  </div>
                  <p className="text-sm text-gray-600">The perfect gift for anyone, delivered instantly by email or mail.</p>
                  <a 
                    href="https://www.amazon.com/gift-cards/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-xs text-[#146EB4] hover:text-[#FF9900] transition mt-2 inline-block"
                  >
                    Buy gift cards →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Related Products */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E]">
              Related Products
            </h2>
            {/* Related Products Pagination Controls */}
            {(!relatedLoading && relatedProducts && relatedProducts.filter(p => p.id !== product.id).length > productsPerPage) && (
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: Math.ceil((relatedProducts.filter(p => p.id !== product.id).length) / productsPerPage) }, (_, index) => (
                  <Button
                    key={index}
                    variant={currentPage === index + 1 ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(index + 1)}
                    className={`w-8 h-8 p-0 ${currentPage === index + 1 ? 'bg-[#FF9900] hover:bg-[#e68a00]' : ''}`}
                  >
                    {index + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (relatedProducts) {
                      const filteredProducts = relatedProducts.filter(p => p.id !== product.id);
                      const maxPage = Math.ceil(filteredProducts.length / productsPerPage);
                      setCurrentPage(prev => Math.min(prev + 1, maxPage));
                    }
                  }}
                  disabled={
                    !relatedProducts || 
                    currentPage === Math.ceil((relatedProducts.filter(p => p.id !== product.id).length) / productsPerPage)
                  }
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
          
          {/* Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedLoading ? (
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <Skeleton className="w-full h-48" />
                  <div className="p-4">
                    <Skeleton className="h-4 w-20 mb-2" />
                    <Skeleton className="h-12 w-full mb-2" />
                    <Skeleton className="h-4 w-32 mb-2" />
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-6 w-20" />
                      <Skeleton className="h-10 w-10 rounded-full" />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              relatedProducts
                ?.filter(p => p.id !== product.id)
                .slice((currentPage - 1) * productsPerPage, currentPage * productsPerPage)
                .map(product => (
                  <ProductCard key={product.id} product={product} />
                ))
            )}
          </div>
          
          {/* Mobile Pagination */}
          {(!relatedLoading && relatedProducts && relatedProducts.filter(p => p.id !== product.id).length > productsPerPage) && (
            <div className="flex justify-center mt-6 lg:hidden">
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: Math.ceil((relatedProducts.filter(p => p.id !== product.id).length) / productsPerPage) }, (_, index) => (
                  <Button
                    key={index}
                    variant={currentPage === index + 1 ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(index + 1)}
                    className={`w-8 h-8 p-0 ${currentPage === index + 1 ? 'bg-[#FF9900] hover:bg-[#e68a00]' : ''}`}
                  >
                    {index + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (relatedProducts) {
                      const filteredProducts = relatedProducts.filter(p => p.id !== product.id);
                      const maxPage = Math.ceil(filteredProducts.length / productsPerPage);
                      setCurrentPage(prev => Math.min(prev + 1, maxPage));
                    }
                  }}
                  disabled={
                    !relatedProducts || 
                    currentPage === Math.ceil((relatedProducts.filter(p => p.id !== product.id).length) / productsPerPage)
                  }
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductPage;
