import React from 'react';

const AffiliateDisclosurePage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-['Poppins'] font-bold text-[#232F3E] mb-6">Affiliate Disclosure</h1>
        
        <div className="prose max-w-none">
          <p className="mb-4">
            Last updated: April 9, 2023
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">FTC Disclosure Compliance</h2>
          <p className="mb-4">
            In accordance with the Federal Trade Commission's guidelines concerning the use of endorsements and testimonials in advertising, we want to make it clear to our visitors that the product links on JamilMaxFinds are primarily affiliate links to Amazon.com.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">What Is an Affiliate Link?</h2>
          <p className="mb-4">
            When you click on one of our product links and subsequently make a purchase, we may receive a small commission from Amazon or other retailers. These affiliate relationships do not affect the price you pay for products—you will pay the same price as if you had visited Amazon directly.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Our Affiliate Relationships</h2>
          <p className="mb-4">
            JamilMaxFinds is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com and affiliated sites.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">How We Select Products</h2>
          <p className="mb-4">
            Our product recommendations are based on genuine research and assessment of product quality, customer reviews, brand reputation, and value for money. While we do earn commissions from affiliate links, we never prioritize products solely based on commission rates or affiliate relationships.
          </p>
          <p className="mb-4">
            We strive to provide honest, unbiased information about products to help you make informed purchasing decisions. Our reputation and your trust are more important to us than any commission we might earn.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Identification of Affiliate Links</h2>
          <p className="mb-4">
            All product links on JamilMaxFinds that lead to Amazon or other retail sites are affiliate links. When you click on these links and make a purchase, we receive a commission at no additional cost to you.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Other Potential Relationships</h2>
          <p className="mb-4">
            In addition to affiliate relationships, JamilMaxFinds may occasionally receive products for review purposes or enter into sponsored content agreements. In such cases, we will clearly disclose these relationships on the relevant content.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Your Privacy</h2>
          <p className="mb-4">
            When you click on our affiliate links, cookies may be placed on your browser to track any purchases made. This tracking is handled by Amazon or other affiliate partners and is subject to their privacy policies. For more information about how we handle your data, please see our <a href="/privacy-policy" className="text-[#146EB4] hover:text-[#FF9900]">Privacy Policy</a>.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Questions About This Disclosure</h2>
          <p className="mb-4">
            If you have any questions about our affiliate relationships or this disclosure, please <a href="/contact" className="text-[#146EB4] hover:text-[#FF9900]">contact us</a>.
          </p>
          
          <p className="mt-8 italic">
            By using JamilMaxFinds, you acknowledge and agree to this Affiliate Disclosure.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AffiliateDisclosurePage;