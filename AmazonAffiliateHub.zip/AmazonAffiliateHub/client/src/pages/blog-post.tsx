import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { CalendarIcon, Clock, Tag, ChevronLeft, ChevronRight, Share2, Facebook, Twitter } from "lucide-react";
import { format } from "date-fns";
import { type Blog, type Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ProductCard from "@/components/ui/product-card";
import { Badge } from "@/components/ui/badge";

const BlogPostPage = () => {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;

  // Fetch blog post
  const { data: blog, isLoading: blogLoading } = useQuery<Blog>({
    queryKey: [`/api/blogs/${slug}`],
    enabled: !!slug,
  });

  // Fetch related products
  const { data: relatedProducts, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/category", blog?.categoryId],
    enabled: !!blog?.categoryId,
  });

  if (blogLoading) {
    return (
      <div className="container py-8">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-12 w-3/4 mb-4" />
          <div className="flex items-center space-x-8 mb-6">
            <Skeleton className="h-6 w-36" />
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-6 w-32" />
          </div>
          <Skeleton className="h-96 w-full mb-8" />
          <div className="space-y-4">
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-5/6" />
            <Skeleton className="h-6 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!blog) {
    return (
      <div className="container py-16 text-center">
        <h1 className="text-3xl font-semibold text-[#232F3E] mb-4">Blog Post Not Found</h1>
        <p className="text-gray-600 mb-8">The blog post you're looking for doesn't exist or has been removed.</p>
        <Link href="/blog">
          <Button className="bg-[#FF9900] hover:bg-amber-600">
            Return to Blog
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="mb-8">
        <Link href="/blog">
          <Button variant="ghost" className="flex items-center text-[#232F3E]">
            <ChevronLeft size={18} className="mr-1" />
            Back to Blog
          </Button>
        </Link>
      </div>

      <article className="max-w-4xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-semibold text-[#232F3E] mb-4">
            {blog.title}
          </h1>

          <div className="flex flex-wrap items-center text-gray-500 mb-6 gap-x-8 gap-y-2">
            <div className="flex items-center">
              <img 
                src={`https://ui-avatars.com/api/?name=${blog.author}&background=random`} 
                alt={blog.author}
                className="w-10 h-10 rounded-full mr-2" 
              />
              <span>By {blog.author}</span>
            </div>
            <div className="flex items-center">
              <CalendarIcon size={16} className="mr-1" />
              <span>{format(new Date(blog.publishDate), 'MMMM d, yyyy')}</span>
            </div>
            <div className="flex items-center">
              <Tag size={16} className="mr-1" />
              <span>Shopping Guides</span>
            </div>
          </div>

          <div className="h-80 sm:h-96 mb-8 overflow-hidden rounded-lg">
            <img 
              src={blog.featureImageUrl} 
              alt={blog.title} 
              className="w-full h-full object-cover"
            />
          </div>
        </header>

        <div className="prose prose-lg max-w-none mb-12">
          <div dangerouslySetInnerHTML={{ __html: blog.content }} />
        </div>

        <footer className="border-t border-gray-200 pt-6 mt-12">
          <div className="flex flex-wrap justify-between items-center">
            <div className="mb-4 sm:mb-0">
              <span className="text-gray-500 mr-2">Share this post:</span>
              <div className="inline-flex space-x-2">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Facebook size={18} />
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Twitter size={18} />
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Share2 size={18} />
                </Button>
              </div>
            </div>

            <div className="flex space-x-2">
              <Badge variant="outline" className="bg-gray-100">
                Amazon
              </Badge>
              <Badge variant="outline" className="bg-gray-100">
                Shopping
              </Badge>
              <Badge variant="outline" className="bg-gray-100">
                Deals
              </Badge>
            </div>
          </div>
        </footer>
      </article>

      {/* Related Products Section */}
      {!productsLoading && relatedProducts && relatedProducts.length > 0 && (
        <div className="mt-16">
          <div className="border-b border-gray-200 mb-8">
            <h2 className="text-2xl font-semibold text-[#232F3E] pb-4">
              Related Products
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {relatedProducts.length > 4 && (
            <div className="mt-8 text-center">
              <Link href={blog.categoryId ? `/category/${blog.categoryId}` : '/products'}>
                <Button 
                  variant="outline" 
                  className="border-[#FF9900] text-[#FF9900] hover:bg-[#FF9900] hover:text-white"
                >
                  View More Products
                  <ChevronRight size={16} className="ml-1" />
                </Button>
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BlogPostPage;