import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import { Product, Category } from '@shared/schema';
import ProductCard from '@/components/ui/product-card';
import { Skeleton } from '@/components/ui/skeleton';
import { FilterOptions } from '@/lib/types';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const CategoryPage = () => {
  const [, params] = useRoute('/category/:slug');
  const slug = params?.slug;
  
  const [filters, setFilters] = useState<FilterOptions>({
    minPrice: 0,
    maxPrice: 1000,
    rating: 0,
    sort: 'price-asc'
  });

  const { data: category, isLoading: categoryLoading } = useQuery<Category>({
    queryKey: [`/api/categories/${slug}`],
    enabled: !!slug,
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: [`/api/products/category/${slug}`],
    enabled: !!slug,
  });

  const { data: allCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const handlePriceChange = (value: number[]) => {
    setFilters({
      ...filters,
      minPrice: value[0],
      maxPrice: value[1]
    });
  };

  const handleRatingChange = (rating: number) => {
    setFilters({
      ...filters,
      rating: filters.rating === rating ? 0 : rating
    });
  };

  const handleSortChange = (value: string) => {
    setFilters({
      ...filters,
      sort: value as any
    });
  };

  const filteredProducts = products?.filter(product => {
    const price = parseFloat(product.price);
    if (price < (filters.minPrice || 0) || price > (filters.maxPrice || 1000)) {
      return false;
    }
    
    if (filters.rating && product.rating < filters.rating) {
      return false;
    }
    
    return true;
  }).sort((a, b) => {
    const priceA = parseFloat(a.price);
    const priceB = parseFloat(b.price);
    
    switch (filters.sort) {
      case 'price-asc':
        return priceA - priceB;
      case 'price-desc':
        return priceB - priceA;
      case 'rating':
        return b.rating - a.rating;
      default:
        return 0;
    }
  });

  return (
    <div className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Breadcrumb */}
        <div className="mb-6 text-sm">
          <a href="/" className="text-gray-500 hover:text-[#FF9900]">Home</a>
          <span className="mx-2 text-gray-400">/</span>
          <span className="text-gray-700">{category?.name || 'Category'}</span>
        </div>
        
        {/* Category Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-['Poppins'] font-semibold text-[#232F3E] mb-2">
            {categoryLoading ? <Skeleton className="h-10 w-48" /> : category?.name || 'All Products'}
          </h1>
          <p className="text-gray-600">Browse our selection of {category?.name || 'products'}</p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Filters */}
          <div className="lg:w-1/4">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-4">Categories</h3>
              <ul className="space-y-2 mb-6">
                <li>
                  <Link href="/category/all">
                    <div className="text-gray-700 hover:text-[#FF9900] flex items-center">
                      <span className={`mr-2 ${slug === 'all' ? 'text-[#FF9900] font-medium' : ''}`}>All Products</span>
                    </div>
                  </Link>
                </li>
                {allCategories?.map(cat => (
                  <li key={cat.id}>
                    <Link href={`/category/${cat.slug}`}>
                      <div className="text-gray-700 hover:text-[#FF9900] flex items-center">
                        <span className={`mr-2 ${cat.slug === slug ? 'text-[#FF9900] font-medium' : ''}`}>{cat.name}</span>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
              
              <h3 className="text-lg font-semibold mb-4">Price Range</h3>
              <div className="mb-6">
                <Slider
                  defaultValue={[filters.minPrice || 0, filters.maxPrice || 1000]}
                  max={1000}
                  step={10}
                  onValueChange={handlePriceChange}
                  className="mb-4"
                />
                <div className="flex justify-between">
                  <span>${filters.minPrice}</span>
                  <span>${filters.maxPrice}</span>
                </div>
              </div>
              
              <h3 className="text-lg font-semibold mb-4">Rating</h3>
              <div className="space-y-2 mb-6">
                {[5, 4, 3, 2, 1].map(rating => (
                  <div key={rating} className="flex items-center">
                    <Checkbox
                      id={`rating-${rating}`}
                      checked={filters.rating === rating}
                      onCheckedChange={() => handleRatingChange(rating)}
                      className="mr-2"
                    />
                    <label htmlFor={`rating-${rating}`} className="flex items-center cursor-pointer">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className={`fas fa-star text-${i < rating ? '[#FF9900]' : 'gray-300'}`}></i>
                      ))}
                      <span className="ml-2">{rating} & up</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Product List */}
          <div className="lg:w-3/4">
            {/* Sort controls */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 p-4 bg-white rounded-lg shadow-sm">
              <p className="text-gray-600 mb-2 sm:mb-0">
                {filteredProducts ? `Showing ${filteredProducts.length} products` : 'Loading products...'}
              </p>
              <Select
                value={filters.sort}
                onValueChange={handleSortChange}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Rating</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Products grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {productsLoading ? (
                Array(6).fill(0).map((_, index) => (
                  <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                    <Skeleton className="w-full h-48" />
                    <div className="p-4">
                      <Skeleton className="h-4 w-20 mb-2" />
                      <Skeleton className="h-12 w-full mb-2" />
                      <Skeleton className="h-4 w-32 mb-2" />
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-6 w-20" />
                        <Skeleton className="h-10 w-10 rounded-full" />
                      </div>
                    </div>
                  </div>
                ))
              ) : filteredProducts?.length ? (
                filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <h3 className="text-xl font-semibold mb-2">No products found</h3>
                  <p className="text-gray-600">Try adjusting your filters or browse a different category</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
