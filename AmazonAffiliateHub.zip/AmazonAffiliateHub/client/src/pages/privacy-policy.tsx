import React from 'react';

const PrivacyPolicyPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-['Poppins'] font-bold text-[#232F3E] mb-6">Privacy Policy</h1>
        
        <div className="prose max-w-none">
          <p className="mb-4">
            Last updated: April 9, 2023
          </p>
          
          <p className="mb-4">
            At JamilMaxFinds, we respect your privacy and are committed to protecting the personal information you share with us. This Privacy Policy explains how we collect, use, and safeguard your information when you visit our website.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Information We Collect</h2>
          
          <h3 className="text-xl font-['Poppins'] font-medium text-[#232F3E] my-3">Personal Information</h3>
          <p className="mb-4">
            We may collect personal information when you voluntarily submit it to us, such as when you:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Subscribe to our newsletter</li>
            <li>Contact us through our contact form</li>
            <li>Leave comments on our website</li>
            <li>Participate in surveys or contests</li>
          </ul>
          <p className="mb-4">
            This information may include your name, email address, and any other details you provide.
          </p>
          
          <h3 className="text-xl font-['Poppins'] font-medium text-[#232F3E] my-3">Automatically Collected Information</h3>
          <p className="mb-4">
            When you visit our website, certain information is automatically collected, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>IP address</li>
            <li>Browser type and version</li>
            <li>Operating system</li>
            <li>Referring website</li>
            <li>Pages viewed and time spent on our website</li>
            <li>Date and time of your visit</li>
          </ul>
          
          <h3 className="text-xl font-['Poppins'] font-medium text-[#232F3E] my-3">Cookies and Similar Technologies</h3>
          <p className="mb-4">
            We use cookies and similar tracking technologies to enhance your browsing experience and to analyze website traffic. You can control cookie settings through your browser preferences.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">How We Use Your Information</h2>
          <p className="mb-4">
            We may use the information we collect for various purposes, including:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Providing and maintaining our website</li>
            <li>Sending newsletters and marketing communications</li>
            <li>Responding to your inquiries and requests</li>
            <li>Improving our website and user experience</li>
            <li>Analyzing usage patterns and trends</li>
            <li>Complying with legal obligations</li>
          </ul>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Third-Party Disclosure</h2>
          <p className="mb-4">
            We do not sell, trade, or otherwise transfer your personal information to outside parties except in the following circumstances:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>To trusted third parties who assist us in operating our website, as long as they agree to keep your information confidential</li>
            <li>When required by law or to protect our rights</li>
            <li>In the event of a merger, acquisition, or sale of all or a portion of our assets</li>
          </ul>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Affiliate Disclosure</h2>
          <p className="mb-4">
            JamilMaxFinds is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program. When you click on our affiliate links and make a purchase, cookies may be placed on your browser to track these purchases. This allows us to earn a commission at no additional cost to you. For more information, please see our <a href="/affiliate-disclosure" className="text-[#146EB4] hover:text-[#FF9900]">Affiliate Disclosure</a>.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Data Security</h2>
          <p className="mb-4">
            We implement reasonable security measures to protect your personal information. However, no method of transmission over the internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Children's Privacy</h2>
          <p className="mb-4">
            Our website is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Changes to This Privacy Policy</h2>
          <p className="mb-4">
            We may update our Privacy Policy from time to time. Any changes will be posted on this page with an updated revision date. We encourage you to review this Privacy Policy periodically.
          </p>
          
          <h2 className="text-2xl font-['Poppins'] font-semibold text-[#232F3E] my-4">Contact Us</h2>
          <p className="mb-4">
            If you have any questions about this Privacy Policy, please <a href="/contact" className="text-[#146EB4] hover:text-[#FF9900]">contact us</a>.
          </p>
          
          <p className="mt-8 italic">
            By using JamilMaxFinds, you consent to our Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;