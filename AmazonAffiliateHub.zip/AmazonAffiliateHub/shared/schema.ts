import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  slug: true,
  icon: true,
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  price: text("price").notNull(),
  originalPrice: text("original_price"),
  discountPercentage: integer("discount_percentage"),
  imageUrl: text("image_url").notNull(),
  rating: integer("rating").notNull(),
  reviewCount: integer("review_count").notNull(),
  categoryId: integer("category_id").notNull(),
  affiliateUrl: text("affiliate_url").notNull(),
  featured: boolean("featured").default(false),
  trending: boolean("trending").default(false),
  hotDeal: boolean("hot_deal").default(false),
});

export const insertProductSchema = createInsertSchema(products).pick({
  title: true,
  slug: true,
  description: true,
  price: true,
  originalPrice: true,
  discountPercentage: true,
  imageUrl: true,
  rating: true,
  reviewCount: true,
  categoryId: true,
  affiliateUrl: true,
  featured: true,
  trending: true,
  hotDeal: true,
});

export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  buttonText: text("button_text").notNull(),
  buttonUrl: text("button_url").notNull(),
  order: integer("order").notNull(),
});

export const insertBannerSchema = createInsertSchema(banners).pick({
  title: true,
  description: true,
  imageUrl: true,
  buttonText: true,
  buttonUrl: true,
  order: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export const blogs = pgTable("blogs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt").notNull(),
  featureImageUrl: text("feature_image_url").notNull(),
  author: text("author").notNull(),
  publishDate: timestamp("publish_date").notNull().defaultNow(),
  categoryId: integer("category_id").references(() => categories.id),
});

export const insertBlogSchema = createInsertSchema(blogs).pick({
  title: true,
  slug: true,
  content: true,
  excerpt: true,
  featureImageUrl: true,
  author: true,
  categoryId: true,
});

export type InsertBanner = z.infer<typeof insertBannerSchema>;
export type Banner = typeof banners.$inferSelect;

export type InsertBlog = z.infer<typeof insertBlogSchema>;
export type Blog = typeof blogs.$inferSelect;
